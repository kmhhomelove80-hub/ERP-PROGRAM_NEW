#Requires -Version 5.1
param(
    [Parameter(Mandatory=$true)][string]$ReleaseRoot,
    [Parameter(Mandatory=$true)][string]$AppRoot,
    [string]$RollbackRoot,
    [switch]$ValidateOnly
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
# This helper only verifies/copies code. Back up DB and stop tasks first.
function Assert-CodePath([string]$Name) {
    if ($Name -match '\\|:|(^|/)\.\.?(/|$)' -or $Name -notmatch '^(config/|inventory/|docs/|scripts/|deploy/windows/(Run-Erp\.ps1|Common\.ps1)$|manage\.py$|requirements(-dev)?\.txt$|README\.md$)') {
        throw ('Disallowed release path: ' + $Name)
    }
    if ($Name -match '(^|/)(\.env|\.venv|__pycache__|runtime[^/]*|secrets[^/]*)(/|$)|\.(sqlite3|dump|clixml|pyc|log)$') {
        throw ('Runtime data is forbidden in a code release: ' + $Name)
    }
}
function Assert-NoLink([string]$Path) {
    $Current = $Path
    while ($Current) {
        if (Test-Path -LiteralPath $Current) {
            if ((Get-Item -LiteralPath $Current -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw ('Linked path refused: ' + $Current) }
        }
        $Parent = Split-Path -Parent $Current
        if ($Parent -eq $Current) { break }
        $Current = $Parent
    }
}
$ReleaseRoot = [IO.Path]::GetFullPath($ReleaseRoot)
$AppRoot = [IO.Path]::GetFullPath($AppRoot)
if (-not (Test-Path -LiteralPath $AppRoot -PathType Container)) { throw 'AppRoot must already exist.' }
$Manifest = Get-Content -LiteralPath (Join-Path $ReleaseRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($Manifest.format -ne 1 -or $Manifest.base_commit -notmatch '^d425d71') { throw 'Unexpected release manifest.' }
$Seen = @{}
foreach ($Entry in $Manifest.files) {
    Assert-CodePath $Entry.path
    if ($Seen.ContainsKey($Entry.path)) { throw 'Duplicate release path.' }
    $Seen[$Entry.path] = $true
    $Source = Join-Path (Join-Path $ReleaseRoot 'app') $Entry.path
    $Target = Join-Path $AppRoot $Entry.path
    Assert-NoLink $Source
    Assert-NoLink $Target
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) { throw ('Missing source: ' + $Entry.path) }
    if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -ne $Entry.sha256) { throw ('Hash mismatch: ' + $Entry.path) }
}
if ($ValidateOnly) { Write-Output ('PASS: verified ' + $Manifest.files.Count + ' code files. No changes made.'); exit 0 }
if (-not $RollbackRoot) { throw 'RollbackRoot is required.' }
$RollbackRoot = [IO.Path]::GetFullPath($RollbackRoot)
if ($RollbackRoot.StartsWith($AppRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) -or $RollbackRoot -eq $AppRoot) { throw 'Keep rollback files outside AppRoot.' }
if (Test-Path -LiteralPath $RollbackRoot) { throw 'RollbackRoot must be a new directory.' }
Assert-NoLink $RollbackRoot
# Refuse the usual server listener; documented checks also cover task children.
if ($env:OS -eq 'Windows_NT') {
    if (Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue) { throw 'ERP is still listening on port 8000. Stop it before applying files.' }
}
New-Item -ItemType Directory -Path $RollbackRoot | Out-Null
$Rollback = @()
foreach ($Entry in $Manifest.files) {
    $Target = Join-Path $AppRoot $Entry.path
    $Exists = Test-Path -LiteralPath $Target -PathType Leaf
    $PreviousHash = $null
    if ($Exists) {
        $PreviousHash = (Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash
        $Saved = Join-Path (Join-Path $RollbackRoot 'files') $Entry.path
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Saved) | Out-Null
        Copy-Item -LiteralPath $Target -Destination $Saved
        if ((Get-FileHash -LiteralPath $Saved -Algorithm SHA256).Hash -ne $PreviousHash) { throw 'Rollback copy verification failed.' }
    }
    $Rollback += [pscustomobject]@{ path=$Entry.path; existed=$Exists; previous_sha256=$PreviousHash; installed_sha256=$Entry.sha256 }
}
@{ format=1; app_root=$AppRoot; files=$Rollback } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $RollbackRoot 'rollback.json') -Encoding UTF8
foreach ($Entry in $Manifest.files) {
    $Source = Join-Path (Join-Path $ReleaseRoot 'app') $Entry.path
    $Target = Join-Path $AppRoot $Entry.path
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Target) | Out-Null
    Copy-Item -LiteralPath $Source -Destination $Target -Force
    if ((Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash -ne $Entry.sha256) { throw ('Installed hash mismatch: ' + $Entry.path) }
}
Write-Output ('PASS: installed ' + $Manifest.files.Count + ' files. Rollback: ' + $RollbackRoot)
