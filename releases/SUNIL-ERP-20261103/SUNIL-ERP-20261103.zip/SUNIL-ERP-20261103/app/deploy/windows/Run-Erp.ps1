﻿#Requires -Version 5.1
param([Parameter(Mandatory=$true)][string]$ConfigPath)
. (Join-Path $PSScriptRoot 'Common.ps1')
$ExitCode = 1
try {
    $Config = Get-SunilConfiguration -ConfigPath $ConfigPath
    Import-SunilEnvironment -Config $Config
    Set-Location -LiteralPath $Config.AppRoot
    $LogRoot = Join-Path $Config.DataRoot 'logs'
    New-Item -ItemType Directory -Force -Path $LogRoot | Out-Null
    $RunId = (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + $PID
    $LogPath = Join-Path $LogRoot ('server-' + $RunId + '.log')
    $OutPath = Join-Path $LogRoot ('server-' + $RunId + '.stdout.log')
    $ErrPath = Join-Path $LogRoot ('server-' + $RunId + '.stderr.log')
    # Start-Process owns native stderr redirection. Windows PowerShell 5.1 must
    # not turn Waitress's ordinary stderr startup messages into NativeCommandError.
    # Leave ErrorActionPreference=Stop intact for configuration/start failures.
    if ([string]$Config.Listen -notmatch '^[a-zA-Z0-9.:\[\]-]+$') { throw 'Listen contains unsupported characters.' }
    Add-Content -LiteralPath $LogPath -Encoding UTF8 -Value ('START ' + (Get-Date -Format o))
    $Child = Start-Process -FilePath $Config.PythonExe -ArgumentList @(
        '-m', 'waitress', ('--listen=' + $Config.Listen), '--threads=4',
        '--max-request-body-size=12582912', 'config.wsgi:application'
    ) -WorkingDirectory $Config.AppRoot -NoNewWindow -Wait -PassThru `
      -RedirectStandardOutput $OutPath -RedirectStandardError $ErrPath
    $ExitCode = $Child.ExitCode
    if ($null -eq $ExitCode) { throw 'Waitress exit code was not available.' }
    Add-Content -LiteralPath $LogPath -Encoding UTF8 -Value ('EXIT ' + (Get-Date -Format o) + ' code=' + $ExitCode)
    if ($ExitCode -ne 0) {
        [Console]::Error.WriteLine('Waitress exited abnormally. See ' + $ErrPath)
    }
} catch {
    [Console]::Error.WriteLine('SUNIL ERP startup failed: ' + $_.Exception.Message)
    if (Get-Variable LogPath -ErrorAction SilentlyContinue) {
        Add-Content -LiteralPath $LogPath -Encoding UTF8 -Value ('FAIL ' + $_.Exception.Message) -ErrorAction Continue
    }
    $ExitCode = 1
}
exit $ExitCode
