"""Two business roles: staff may write, workers may read and submit movement requests through a dedicated endpoint."""
from functools import wraps
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied


def warehouse_access(view):
    @login_required
    @wraps(view)
    def wrapped(request, *args, **kwargs):
        if not request.user.is_active:
            raise PermissionDenied
        if request.method not in ('GET', 'HEAD', 'OPTIONS') and not request.user.is_staff:
            raise PermissionDenied('작업자 계정은 조회·이동 요청만 가능합니다. 이 작업은 관리자 권한이 필요합니다.')
        return view(request, *args, **kwargs)
    return wrapped


def warehouse_write(view):
    @warehouse_access
    @wraps(view)
    def wrapped(request, *args, **kwargs):
        if not request.user.is_staff:
            raise PermissionDenied('모든 권한이 필요한 작업입니다.')
        return view(request, *args, **kwargs)
    return wrapped
