SUNIL ERP 2026-11-03
Base d425d71 -> source 1460a6c (full SHA in manifest.json).
Read WINDOWS_UPDATE.md before applying.
Backup -> stop tasks/server -> verify/copy code -> migration check and collectstatic -> restart -> verify -> local backup.
No new migration or dependency changes.
Do not replace runtime.local.json, DPAPI files, database, Caddyfile or scheduled-task definitions.
Preserve current internal HTTP and DEBUG=1.
Windows 5.1/task/DPAPI and actual Android Binary Eye verification must be performed on site.
