#Requires -Version 5.1
param([Parameter(Mandatory=$true)][string]$RollbackRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
function Assert-NoLink([string]$Path) {
    $Current = $Path
    while ($Current) {
        if (Test-Path -LiteralPath $Current) {
            if ((Get-Item -LiteralPath $Current -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw ('Linked path refused: ' + $Current) }
        }
        $Parent = Split-Path -Parent $Current
        if ($Parent -eq $Current) { break }
        $Current = $Parent
    }
}
$RollbackRoot = [IO.Path]::GetFullPath($RollbackRoot)
Assert-NoLink $RollbackRoot
$Manifest = Get-Content -LiteralPath (Join-Path $RollbackRoot 'rollback.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($Manifest.format -ne 1) { throw 'Unexpected rollback format.' }
$AppRoot = [IO.Path]::GetFullPath($Manifest.app_root)
if ($env:OS -eq 'Windows_NT') {
    if (Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue) { throw 'Stop ERP before rollback.' }
}
foreach ($Entry in $Manifest.files) {
    if ($Entry.path -match '\\|:|(^|/)\.\.?(/|$)' -or $Entry.path -notmatch '^(config/|inventory/|docs/|scripts/|deploy/windows/(Run-Erp\.ps1|Common\.ps1)$|manage\.py$|requirements(-dev)?\.txt$|README\.md$)') { throw 'Disallowed rollback path.' }
    $Target = Join-Path $AppRoot $Entry.path
    Assert-NoLink $Target
    if (Test-Path -LiteralPath $Target) {
        if ((Get-Item -LiteralPath $Target -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked target refused.' }
        $Hash = (Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash
        if ($Hash -ne $Entry.installed_sha256 -and $Hash -ne $Entry.previous_sha256) { throw ('File changed after deployment; review manually: ' + $Entry.path) }
    }
    if ($Entry.existed) {
        $Source = Join-Path (Join-Path $RollbackRoot 'files') $Entry.path
        Assert-NoLink $Source
        if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -ne $Entry.previous_sha256) { throw 'Rollback source hash mismatch.' }
    }
}
foreach ($Entry in $Manifest.files) {
    $Target = Join-Path $AppRoot $Entry.path
    if ($Entry.existed) {
        $Source = Join-Path (Join-Path $RollbackRoot 'files') $Entry.path
        Copy-Item -LiteralPath $Source -Destination $Target -Force
    } elseif (Test-Path -LiteralPath $Target) {
        Remove-Item -LiteralPath $Target
    }
}
Write-Output 'PASS: code rollback completed. Runtime settings, secrets and DB were not touched.'
