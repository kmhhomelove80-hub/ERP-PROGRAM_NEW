SUNIL ERP 통합 업데이트 — 2026-11-04

1. 회사 ERP 서버에 기존 Windows 계정으로 로그인하세요.
2. 이 폴더를 C:\SUNIL\updates\SUNIL-ERP-20261104-integrated-v3 에 둡니다.
3. UPDATE_GUIDE.html을 열어 같은 계정의 관리자 PowerShell에서 check부터 실행합니다.
4. 통과하면 직원들의 처리를 잠시 멈추고 apply --work-paused를 실행합니다.

보류한 EXE는 사용하지 않습니다. 백신을 끄거나 허용·제외 설정을 하지 마세요.
app 폴더를 수동 덮어쓰기 하지 마세요. DB 초기화·재이관은 하지 않습니다.
